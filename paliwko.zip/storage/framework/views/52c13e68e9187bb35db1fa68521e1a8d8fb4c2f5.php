<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="jumbotron text-center">
    	<h2><?php echo e($user->name); ?></h2>
        <p>
        	<strong>Nazwa:</strong> <?php echo e($user->name); ?><br>
            <strong>Email:</strong> <?php echo e($user->email); ?>

        </p>
	</div>
	<div class="list-group text-center">
	<a href="<?php echo e(URL::to('users/' . $user->id . '/edit')); ?>" class="list-group-item">Zmien adres email</a>
	<form class="list-group-item" method="POST" action="<?php echo e(url('users/'.$user->id)); ?>">
                    	<input type="hidden" name="_method" value="DELETE">
                    	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    	<button type="submit" class="btn btn-primary">Usun konto</button>
                    </form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>