<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="panel panel-default">
    	<div class="panel-heading">Users</div>
    	<div class="panel-body">
        	<table class="table table-striped task-table">
        		<thead>
                	<th>Nazwa</th>
                	<th>Email</th>
                	<th>Uprawnienia</th>
            	</thead>
            	<tbody>
                	<?php foreach($users as $user): ?>
                    	<tr>
                        	<!-- Task Name -->
                            <td class="table-text">
                            	<div><?php echo e($user->name); ?></div>
                            </td>
                            
                            <td class="table-text">
                            	<div><?php echo e($user->email); ?></div>
                            </td>
                            <td class="table-text">
                            	<div><?php echo e($user->role_name); ?></div>
                            </td>
							<?php if (\Entrust::hasRole('admin')) : ?>
                            <?php if($user->role_name == 'sub'): ?>
                            <td>
                            	<a class="btn btn-small btn-info" href="<?php echo e(URL::to('users/' . $user->id . '/giveModerator')); ?>">Nadanie Moderatora<i class="glyphicon glyphicon-arrow-up"></i></a>
                            </td>
                            <?php elseif($user->role_name == 'mod'): ?>
                            <td>
                            	<a class="btn btn-small btn-info" href="<?php echo e(URL::to('users/' . $user->id . '/takeModerator')); ?>">Odebranie Moderatora<i class="glyphicon glyphicon-arrow-down"></i></a>
                            </td>
                            <?php endif; ?>
                            <?php endif; // Entrust::hasRole ?>
                        </tr>
                        <?php endforeach; ?>
                </tbody>
        	</table>
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>